package com.example.fvm_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
